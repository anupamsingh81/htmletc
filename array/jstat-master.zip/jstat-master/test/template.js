var vows = require('vows');
var assert = require('assert');
var suite = vows.describe('jStat');

require('../env.js');

suite.addBatch({
  '': {
    'topic': function() {
      return jStat;
    },
    '': function(jStat) {
    }
  }
});

suite.export(module);
